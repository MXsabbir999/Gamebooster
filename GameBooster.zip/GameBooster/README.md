# ⚡ Game Booster — Shizuku Edition

Purple & Black Gaming UI | Real ADB Commands | No Fake Tricks

---

## 📱 কিভাবে APK পাবে (GitHub দিয়ে, free):

### Step 1 — GitHub account বানাও
- **github.com** এ গিয়ে Sign up করো (free)

### Step 2 — New Repository বানাও
- "+" icon → "New repository"
- Name: `GameBooster`
- Public রাখো
- **Create repository** click করো

### Step 3 — Files upload করো
- "uploading an existing file" click করো
- সব files এবং folders drag করো (folder structure ঠিক রাখতে হবে)
- "Commit changes" click করো

### Step 4 — APK auto-build হবে
- **Actions** tab এ যাও
- "Build Game Booster APK" চলছে দেখবে (3-5 মিনিট)
- Green checkmark আসলে সফল

### Step 5 — APK download করো
- Actions → সেই run এ click করো
- নিচে **Artifacts** section এ **GameBooster-APK** download করো
- Phone এ install করো!

---

## 🎮 কিভাবে use করবে:

1. **Shizuku** app install করো ও start করো
2. Game Booster APK install করো
3. Open করো → Shizuku permission দাও
4. Game এর আগে → **🎮 GAME MODE** button চাপো
5. Game শেষে → **📱 NORMAL MODE** চাপো

---

## ✅ যা real হয়:
- Display resolution & density change (wm size/density)
- Animation kill (0 scale = instant transitions)
- Touch speed increase (pointer_speed 6)
- Private DNS → Cloudflare (faster)
- Max performance power mode
- Background process limit
- Network stability tweaks

কোনো fake loading নেই। Terminal এ সব real output দেখা যাবে।
