package com.sabbir.gamebooster

import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {

    private lateinit var btnGameMode: Button
    private lateinit var btnNormalMode: Button
    private lateinit var tvLog: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvStatusDot: TextView
    private lateinit var scrollLog: ScrollView

    private val logBuilder = StringBuilder()

    // =============================================
    // GAME MODE — exact commands from user
    // =============================================
    private val gameModeGroups = listOf(
        "DISPLAY PERFORMANCE BOOST" to listOf(
            "wm size 540x1200",
            "wm density 220"
        ),
        "TOUCH + AIM RESPONSE" to listOf(
            "settings put system pointer_speed 6"
        ),
        "ANIMATION KILL (SMOOTH FPS)" to listOf(
            "settings put global window_animation_scale 0",
            "settings put global transition_animation_scale 0",
            "settings put global animator_duration_scale 0"
        ),
        "BACKGROUND OPTIMIZATION" to listOf(
            "settings put global activity_manager_constants max_cached_processes=6"
        ),
        "NETWORK STABILITY" to listOf(
            "settings put global wifi_scan_throttle_enabled 0",
            "settings put global mobile_data_always_on 0"
        ),
        "PRIVATE DNS (FAST + STABLE)" to listOf(
            "settings put global private_dns_mode hostname",
            "settings put global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com"
        ),
        "MAX PERFORMANCE POWER MODE" to listOf(
            "cmd power set-mode 0",
            "cmd power set-adaptive-power-saver-enabled false"
        ),
        "LIGHT CLEAN BOOST" to listOf(
            "cmd activity idle-maintain"
        )
    )

    // =============================================
    // NORMAL MODE — exact commands from user
    // =============================================
    private val normalModeGroups = listOf(
        "RESTORING DISPLAY" to listOf(
            "wm size reset",
            "wm density reset"
        ),
        "RESTORING ANIMATIONS" to listOf(
            "settings put global window_animation_scale 0.5",
            "settings put global transition_animation_scale 0.5",
            "settings put global animator_duration_scale 0.5"
        ),
        "RESTORING BACKGROUND PROCESSES" to listOf(
            "settings put global activity_manager_constants max_cached_processes=16"
        ),
        "RESTORING NETWORK" to listOf(
            "settings put global wifi_scan_throttle_enabled 1",
            "settings put global mobile_data_always_on 1"
        ),
        "TURNING OFF PRIVATE DNS" to listOf(
            "settings put global private_dns_mode off"
        ),
        "RESTORING TOUCH SPEED" to listOf(
            "settings put system pointer_speed 7"
        ),
        "RESTORING NORMAL POWER MODE" to listOf(
            "cmd power set-mode 1",
            "cmd power set-adaptive-power-saver-enabled true"
        )
    )

    private val shizukuPermListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) {
            setShizukuReady()
        } else {
            setShizukuError("Permission denied — open Shizuku and grant permission")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnGameMode   = findViewById(R.id.btn_game_mode)
        btnNormalMode = findViewById(R.id.btn_normal_mode)
        tvLog         = findViewById(R.id.tv_log)
        tvStatus      = findViewById(R.id.tv_status)
        tvStatusDot   = findViewById(R.id.tv_status_dot)
        scrollLog     = findViewById(R.id.scroll_log)

        Shizuku.addRequestPermissionResultListener(shizukuPermListener)
        checkShizuku()

        btnGameMode.setOnClickListener   { runCommandGroups(gameModeGroups,   isGameMode = true)  }
        btnNormalMode.setOnClickListener { runCommandGroups(normalModeGroups, isGameMode = false) }
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuPermListener)
    }

    // ── Shizuku status check ──────────────────────
    private fun checkShizuku() {
        try {
            when {
                !Shizuku.pingBinder() ->
                    setShizukuError("Shizuku not running — open Shizuku app first")

                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED ->
                    setShizukuReady()

                else -> {
                    tvStatus.text = "Requesting permission..."
                    Shizuku.requestPermission(0)
                }
            }
        } catch (e: Exception) {
            setShizukuError(e.message ?: "Unknown error")
        }
    }

    private fun setShizukuReady() {
        runOnUiThread {
            tvStatusDot.setTextColor(Color.parseColor("#00FF88"))
            tvStatus.text = "Shizuku Connected — Ready"
            tvStatus.setTextColor(Color.parseColor("#888888"))
            btnGameMode.isEnabled   = true
            btnNormalMode.isEnabled = true
        }
    }

    private fun setShizukuError(msg: String) {
        runOnUiThread {
            tvStatusDot.setTextColor(Color.parseColor("#FF4444"))
            tvStatus.text = msg
            tvStatus.setTextColor(Color.parseColor("#FF6666"))
            btnGameMode.isEnabled   = false
            btnNormalMode.isEnabled = false
        }
    }

    // ── Run command groups ────────────────────────
    private fun runCommandGroups(
        groups: List<Pair<String, List<String>>>,
        isGameMode: Boolean
    ) {
        btnGameMode.isEnabled   = false
        btnNormalMode.isEnabled = false
        logBuilder.clear()

        val header = if (isGameMode)
            "⚡ GAME MODE ACTIVATING...\n"
        else
            "📱 RESTORING NORMAL MODE...\n"
        appendLog(header)

        CoroutineScope(Dispatchers.IO).launch {
            var success = 0
            var failed  = 0

            for ((groupName, commands) in groups) {
                appendLog("\n▌ $groupName")

                for (cmd in commands) {
                    val preview = if (cmd.length > 48) cmd.take(48) + "…" else cmd
                    appendLog("  › $preview")

                    try {
                        val out = runShell(cmd)
                        success++
                        appendLog("    ✅${if (out.isNotEmpty()) " $out" else ""}")
                    } catch (e: Exception) {
                        failed++
                        appendLog("    ❌ ${e.message?.take(60)}")
                    }

                    delay(80)
                }
            }

            val footer = if (isGameMode)
                "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n🎮 GAME MODE ACTIVE!\n$success applied · $failed failed\nLaunch your game now!\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            else
                "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n📱 NORMAL MODE RESTORED\n$success applied · $failed failed\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

            appendLog(footer)

            withContext(Dispatchers.Main) {
                btnGameMode.isEnabled   = true
                btnNormalMode.isEnabled = true
            }
        }
    }

    // ── Shell execution via Shizuku ───────────────
    private fun runShell(command: String): String {
        val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
        val stdout  = BufferedReader(InputStreamReader(process.inputStream)).readText().trim()
        val stderr  = BufferedReader(InputStreamReader(process.errorStream)).readText().trim()
        val exit    = process.waitFor()
        if (exit != 0 && stderr.isNotEmpty()) throw RuntimeException(stderr.take(60))
        return stdout
    }

    // ── Log helper ────────────────────────────────
    private fun appendLog(line: String) {
        runOnUiThread {
            logBuilder.append(line).append("\n")
            tvLog.text = logBuilder.toString()
            scrollLog.post { scrollLog.fullScroll(View.FOCUS_DOWN) }
        }
    }
}
